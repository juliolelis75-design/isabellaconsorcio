import React from "react";
import { BadgePercent, Wallet, HeadphonesIcon, TrendingUp, Shield, Clock } from "lucide-react";
import { motion } from "framer-motion";

const benefits = [
  {
    icon: BadgePercent,
    title: "Sem juros, mais tranquilidade",
    description: "Diferente do financiamento, no consórcio você não paga juros. Economia real no seu bolso.",
  },
  {
    icon: Wallet,
    title: "Parcelas flexíveis",
    description: "Parcelas que cabem no seu orçamento, com redução de até 45% até a contemplação.",
  },
  {
    icon: HeadphonesIcon,
    title: "Consultoria especializada",
    description: "Atendimento personalizado com Isabella Villani para te acompanhar em cada etapa.",
  },
  {
    icon: TrendingUp,
    title: "Potencialize seu lance",
    description: "Você pode usar parte do seu crédito para ofertar lances e antecipar sua contemplação.",
  },
  {
    icon: Shield,
    title: "Segurança Porto Seguro",
    description: "Respaldado por uma das maiores seguradoras do Brasil, com mais de 80 anos de mercado.",
  },
  {
    icon: Clock,
    title: "Até 90 meses para pagar",
    description: "Planos flexíveis de 50 a 90 meses para você escolher o que melhor se encaixa.",
  },
];

export default function BenefitsSection({ coupleImage }) {
  return (
    <section id="vantagens" className="py-20 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="rounded-3xl overflow-hidden shadow-2xl shadow-primary/10">
              <img
                src={coupleImage}
                alt="Casal feliz no carro novo"
                className="w-full h-auto object-cover"
              />
            </div>
            {/* Floating Card */}
            <div className="absolute -bottom-6 -right-4 sm:right-4 bg-white rounded-2xl p-5 shadow-xl max-w-[220px]">
              <div className="text-3xl font-extrabold text-primary">45%</div>
              <p className="text-sm text-muted-foreground mt-1">
                de redução nas parcelas até a contemplação
              </p>
            </div>
          </motion.div>

          {/* Benefits Grid */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <span className="text-primary font-semibold text-sm tracking-wider uppercase">
                Vantagens
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-10">
                Por que fazer o Consórcio de Carros da Porto?
              </h2>
            </motion.div>

            <div className="grid sm:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.08 }}
                  className="flex gap-4"
                >
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <benefit.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-sm mb-1">
                      {benefit.title}
                    </h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {benefit.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}