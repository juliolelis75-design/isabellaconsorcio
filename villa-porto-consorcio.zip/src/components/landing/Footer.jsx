import React from "react";
import { Phone, Mail, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-foreground text-white/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="mb-4">
              <img
                src="https://media.base44.com/images/public/69bc0060bc4e860dd5230ca2/f8d5dbb5d_IMG_9655.png"
                alt="Isabella Villani Logo"
                className="w-48 brightness-0 invert opacity-90"
              />
            </div>
            <p className="text-sm leading-relaxed text-white/60 mt-4">
              Consultora autorizada Porto Seguro, especialista em consórcios e investimentos. Te ajudo a realizar seus sonhos de forma inteligente e planejada.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Navegação</h4>
            <nav className="space-y-3">
              {[
                { label: "Início", href: "#inicio" },
                { label: "Como Funciona", href: "#como-funciona" },
                { label: "Vantagens", href: "#vantagens" },
                { label: "Depoimentos", href: "#depoimentos" },
                { label: "Dúvidas", href: "#faq" },
                { label: "Contato", href: "#contato" },
              ].map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="block text-sm text-white/50 hover:text-white transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </nav>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contato</h4>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-primary shrink-0" />
                <a href="https://wa.me/5531936183846" className="text-sm hover:text-white transition-colors">(31) 93618-3846</a>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-primary shrink-0" />
                <a href="mailto:isabella.villani@portoseguro.com.br" className="text-sm hover:text-white transition-colors">isabella.villani@portoseguro.com.br</a>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <span className="text-sm">Av. Bias Fortes, 382, Lourdes<br />Belo Horizonte - MG</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/40">
            © {new Date().getFullYear()} Isabella Villani - Consórcios Porto Seguro. Todos os direitos reservados.
          </p>
          <p className="text-xs text-white/40">
            Porto Seguro Consórcios S.A. - CNPJ: 57.128.221/0001-17
          </p>
        </div>
      </div>
    </footer>
  );
}