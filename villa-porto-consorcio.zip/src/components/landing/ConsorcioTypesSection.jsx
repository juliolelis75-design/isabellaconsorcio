import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Home, Car, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";

const types = [
  {
    icon: Home,
    title: "Consórcio de Imóvel",
    description:
      "Planejamento inteligente para escolher o imóvel que deseja: casa, terreno, apartamento ou reforma.",
    credit: "Até R$ 999.999",
    href: "#contato",
    image: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=600&q=80",
  },
  {
    icon: Car,
    title: "Consórcio de Carro",
    description:
      "Do primeiro carro à sua próxima conquista: de forma simples, você escolhe o automóvel certo no seu tempo.",
    credit: "Até R$ 300.000",
    href: "#contato",
    image: "https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=600&q=80",
  },
  {
    icon: Truck,
    title: "Consórcio de Veículo Pesado",
    description:
      "A força certa para impulsionar seu negócio. Amplie sua frota com ônibus, caminhão ou trator.",
    credit: "Até R$ 999.999",
    href: "#contato",
    image: "https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=600&q=80",
  },
];

export default function ConsorcioTypesSection() {
  return (
    <section id="tipos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <span className="text-primary font-semibold text-sm tracking-wider uppercase">
            Nossos Produtos
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3">
            Conheça os tipos de consórcio
          </h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Escolha o consórcio ideal para o seu objetivo e simule seu plano com a Isabella.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {types.map((type, index) => (
            <motion.div
              key={type.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="rounded-2xl overflow-hidden border border-border/40 hover:shadow-xl hover:shadow-primary/8 transition-all duration-300 group"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={type.image}
                  alt={type.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent" />
                <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-3 py-1.5">
                  <type.icon className="w-4 h-4 text-white" />
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-lg font-bold text-foreground mb-3">{type.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-5">
                  {type.description}
                </p>
                <a href={type.href}>
                  <Button
                    variant="outline"
                    className="w-full rounded-xl border-primary/30 text-primary hover:bg-primary hover:text-white transition-all"
                  >
                    Simular agora
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}