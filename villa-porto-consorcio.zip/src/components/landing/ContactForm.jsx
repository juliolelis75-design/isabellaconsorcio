import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone, Send, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const CREDIT_RANGES = [
  "R$ 10.000 a R$ 50.000",
  "R$ 50.001 a R$ 100.000",
  "R$ 100.001 a R$ 150.000",
  "R$ 150.001 a R$ 200.000",
  "R$ 200.001 a R$ 300.000",
  "R$ 300.001 a R$ 400.000",
  "R$ 400.001 a R$ 500.000",
  "R$ 500.001 a R$ 600.000",
  "R$ 600.001 a R$ 700.000",
  "R$ 700.001 a R$ 800.000",
  "R$ 800.001 a R$ 900.000",
  "R$ 900.001 a R$ 999.999",
];

export default function ContactForm() {
  const [form, setForm] = useState({
    nome: "",
    email: "",
    telefone: "",
    cpf: "",
    mensagem: "",
    tipo_consorcio: "",
    faixa_credito: "",
  });
  const [aceite, setAceite] = useState(false);
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleChange = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.nome || !form.telefone) {
      toast.error("Preencha pelo menos seu nome e telefone.");
      return;
    }
    setLoading(true);
    try {
      await base44.entities.Lead.create({
        nome: form.nome,
        email: form.email,
        telefone: form.telefone,
        cpf_cnpj: form.cpf,
        mensagem: `[${form.tipo_consorcio || "Não informado"} | ${form.faixa_credito || "Não informado"}] ${form.mensagem}`,
        status: "novo",
      });
      setSent(true);
      toast.success("Mensagem enviada com sucesso! Entrarei em contato em breve.");
    } catch (err) {
      toast.error("Erro ao enviar. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  if (sent) {
    return (
      <section id="contato" className="py-20 bg-muted">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl p-12 shadow-lg"
          >
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Send className="w-7 h-7 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-3">Mensagem Enviada!</h3>
            <p className="text-muted-foreground">
              Obrigada pelo seu interesse! Entrarei em contato em breve para te ajudar a conquistar seu veículo.
            </p>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id="contato" className="py-20 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Side */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Phone className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
                Vamos falar com você
              </h2>
            </div>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Preencha o formulário e eu, Isabella Villani, entrarei em contato para te ajudar a encontrar o melhor plano de consórcio para o seu momento de vida.
            </p>
            <div className="space-y-4">
              {[
                "Atendimento personalizado e consultoria especializada",
                "Simulação gratuita e sem compromisso",
                "Acompanhamento em todas as etapas do consórcio",
              ].map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center mt-0.5 shrink-0">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                  </div>
                  <span className="text-foreground">{item}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <form
              onSubmit={handleSubmit}
              className="bg-white rounded-2xl p-8 shadow-lg shadow-primary/5 space-y-5"
            >
              <Input
                placeholder="Nome completo"
                value={form.nome}
                onChange={(e) => handleChange("nome", e.target.value)}
                className="h-12 rounded-xl border-border/60"
              />
              <Input
                type="email"
                placeholder="E-mail"
                value={form.email}
                onChange={(e) => handleChange("email", e.target.value)}
                className="h-12 rounded-xl border-border/60"
              />
              <Input
                placeholder="Telefone para contato"
                value={form.telefone}
                onChange={(e) => handleChange("telefone", e.target.value)}
                className="h-12 rounded-xl border-border/60"
              />
              <Input
                placeholder="CPF / CNPJ"
                value={form.cpf}
                onChange={(e) => handleChange("cpf", e.target.value)}
                className="h-12 rounded-xl border-border/60"
              />

              {/* Tipo de Consórcio */}
              <Select onValueChange={(value) => handleChange("tipo_consorcio", value)}>
                <SelectTrigger className="h-12 rounded-xl border-border/60">
                  <SelectValue placeholder="Tipo de consórcio" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Consórcio de Carro">Consórcio de Carro</SelectItem>
                  <SelectItem value="Consórcio de Imóvel">Consórcio de Imóvel</SelectItem>
                  <SelectItem value="Consórcio de Veículo Pesado">Consórcio de Veículo Pesado</SelectItem>
                </SelectContent>
              </Select>

              {/* Faixa de Crédito */}
              <Select onValueChange={(value) => handleChange("faixa_credito", value)}>
                <SelectTrigger className="h-12 rounded-xl border-border/60">
                  <SelectValue placeholder="Faixa de crédito desejada" />
                </SelectTrigger>
                <SelectContent>
                  {CREDIT_RANGES.map((range) => (
                    <SelectItem key={range} value={range}>{range}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Input
                placeholder="Mensagem (opcional)"
                value={form.mensagem}
                onChange={(e) => handleChange("mensagem", e.target.value)}
                className="h-12 rounded-xl border-border/60"
              />

              <div className="flex items-start gap-3">
                <Checkbox
                  checked={aceite}
                  onCheckedChange={setAceite}
                  className="mt-1"
                />
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Aceito receber o contato de um consultor por telefone. Ao clicar em "Enviar" você está ciente de que seus dados serão tratados conforme a Política de Privacidade da Porto Seguro.
                </p>
              </div>

              <Button
                type="submit"
                disabled={loading || !aceite}
                className="w-full h-12 bg-primary hover:bg-primary/90 rounded-xl text-base font-semibold"
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    Enviar
                    <Send className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}