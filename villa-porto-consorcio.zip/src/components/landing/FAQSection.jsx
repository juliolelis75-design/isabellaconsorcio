import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { motion } from "framer-motion";

const faqs = [
  // Imóvel
  {
    question: "Como funciona o consórcio de imóvel?",
    answer:
      "No consórcio de imóvel você faz parte de um grupo e paga parcelas mensais sem juros. Todo mês ocorrem contemplações por sorteio ou lance. Ao ser contemplado, recebe a carta de crédito para adquirir casa, apartamento, terreno ou até realizar uma reforma.",
  },
  {
    question: "Posso usar o consórcio de imóvel para comprar terreno ou reformar?",
    answer:
      "Sim! A carta de crédito do consórcio de imóvel pode ser usada para comprar imóvel residencial ou comercial, terreno, construir ou reformar. É uma modalidade bastante flexível para quem quer investir no patrimônio.",
  },
  // Carro
  {
    question: "Como funciona o consórcio de carro?",
    answer:
      "Você integra um grupo de consorciados e paga parcelas mensais. Mensalmente são realizados sorteios e lances para contemplação. Ao ser contemplado, recebe a carta de crédito para comprar o automóvel de sua escolha — novo ou usado — à vista, com maior poder de negociação.",
  },
  {
    question: "Posso usar a carta de crédito de carro em qualquer veículo?",
    answer:
      "Sim! A carta de crédito pode ser utilizada para adquirir automóveis novos ou usados de qualquer marca e modelo. Você também pode destinar parte do crédito para despesas com documentação, transferência e seguro.",
  },
  // Veículo Pesado
  {
    question: "Como funciona o consórcio de veículo pesado?",
    answer:
      "O consórcio de veículo pesado segue a mesma lógica: parcelas mensais sem juros, contemplação por sorteio ou lance. A carta de crédito pode ser usada para adquirir caminhões, ônibus, tratores, máquinas agrícolas e outros veículos de grande porte.",
  },
  {
    question: "O consórcio de veículo pesado é indicado para empresas?",
    answer:
      "Com certeza! É uma excelente opção para ampliar frotas ou renovar equipamentos sem comprometer o fluxo de caixa da empresa. Sem juros e com parcelas acessíveis, o consórcio permite planejar o crescimento do negócio de forma inteligente.",
  },
  // Geral
  {
    question: "Qual a diferença entre consórcio e financiamento?",
    answer:
      "No consórcio você NÃO paga juros, apenas uma taxa de administração diluída nas parcelas. No financiamento, os juros podem representar até 100% do valor do bem. O consórcio é mais econômico e inteligente para quem pode planejar a aquisição.",
  },
  {
    question: "Posso dar lance para ser contemplado mais rápido?",
    answer:
      "Sim! Todo mês nas assembleias você pode ofertar lances para antecipar sua contemplação. Também é possível utilizar parte do próprio crédito para potencializar o lance, aumentando suas chances.",
  },
];

export default function FAQSection() {
  return (
    <section id="faq" className="py-20 bg-muted">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="text-primary font-semibold text-sm tracking-wider uppercase">
            Dúvidas Frequentes
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3">
            Tire suas dúvidas sobre o Consórcio
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-white rounded-xl border border-border/40 px-6 shadow-sm"
              >
                <AccordionTrigger className="text-left font-semibold text-foreground hover:no-underline py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-5 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
}