import React from "react";
import { Search, Users, Star, CreditCard } from "lucide-react";
import { motion } from "framer-motion";

const steps = [
  {
    icon: Search,
    title: "Comece pelo seu sonho",
    description:
      "Simule o valor do bem que deseja — carro, imóvel ou veículo pesado — e escolha um plano que se encaixe no seu momento de vida.",
    color: "bg-blue-50 text-blue-600",
  },
  {
    icon: Users,
    title: "Sonhe junto com mais pessoas",
    description:
      "Você passa a fazer parte de um grupo com objetivos semelhantes e constrói sua conquista pagando as parcelas mensais.",
    color: "bg-indigo-50 text-indigo-600",
  },
  {
    icon: Star,
    title: "Contemplação: a virada",
    description:
      "Todo mês acontecem sorteios e você também pode ofertar lances. Quando sua cota for contemplada, sua carta de crédito será liberada.",
    color: "bg-violet-50 text-violet-600",
  },
  {
    icon: CreditCard,
    title: "Conquiste com poder de compra",
    description:
      "Com a carta de crédito em mãos, você compra à vista, negocia melhor e transforma seu sonho em patrimônio.",
    color: "bg-emerald-50 text-emerald-600",
  },
];

export default function StepsSection() {
  return (
    <section id="como-funciona" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-primary font-semibold text-sm tracking-wider uppercase">
            Passo a Passo
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3">
            São poucos passos até a conquista do seu objetivo
          </h2>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative"
            >
              <div className="bg-white rounded-2xl p-6 border border-border/40 hover:shadow-xl hover:shadow-primary/5 transition-all duration-300 h-full">
                {/* Step Number */}
                <div className="absolute -top-3 -left-1 w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-bold flex items-center justify-center shadow-lg">
                  {index + 1}
                </div>

                <div className={`w-14 h-14 rounded-2xl ${step.color} flex items-center justify-center mb-5`}>
                  <step.icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-3">
                  {step.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}