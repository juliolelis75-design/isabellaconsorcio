import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, ShieldCheck } from "lucide-react";
import { motion } from "framer-motion";

export default function HeroSection({ heroImage }) {
  return (
    <section
      id="inicio"
      className="relative min-h-[90vh] flex items-center overflow-hidden pt-20"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Consórcio de Veículos Porto Seguro"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/80 to-primary/40" />
      </div>

      {/* Logo IV - canto superior direito */}
      <div className="absolute top-24 right-6 md:right-12 z-10 opacity-80">
        <img
          src="https://media.base44.com/images/public/69bc0060bc4e860dd5230ca2/f8d5dbb5d_IMG_9655.png"
          alt="Isabella Villani Logo"
          className="w-36 md:w-48 brightness-0 invert"
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
              <ShieldCheck className="w-4 h-4 text-white" />
              <span className="text-white/90 text-sm font-medium">
                Consultora Autorizada Porto Seguro
              </span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6">
              Consórcio Porto Bank
              <span className="block text-white/80 text-2xl sm:text-3xl lg:text-4xl mt-2 font-semibold">
                Carro · Imóvel · Veículo Pesado
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-white/85 mb-8 leading-relaxed max-w-lg">
              Realize seus sonhos sem juros e sem entrada. Parcelas que cabem no seu bolso, com toda a segurança da Porto Seguro.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <a href="#contato">
                <Button
                  size="lg"
                  className="bg-white text-primary hover:bg-white/90 rounded-full px-8 text-base font-semibold shadow-lg shadow-black/20"
                >
                  Fale com a Isabella
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </a>
              <a href="#como-funciona">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-white/40 text-white hover:bg-white/10 rounded-full px-8 text-base font-semibold bg-transparent"
                >
                  Como Funciona
                </Button>
              </a>
            </div>
          </motion.div>

          {/* Trust Badges */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-12 flex flex-wrap gap-6"
          >
            {[
              "Sem Juros",
              "Sem Entrada",
              "Parcelas Reduzidas",
              "Até 90 meses",
            ].map((badge) => (
              <div
                key={badge}
                className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2"
              >
                <div className="w-2 h-2 rounded-full bg-green-400" />
                <span className="text-white/90 text-sm font-medium">{badge}</span>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}