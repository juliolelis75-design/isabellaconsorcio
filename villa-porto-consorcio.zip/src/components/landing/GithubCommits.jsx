import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { GitCommit, ExternalLink, Loader2, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

const OWNER = "juliolelis75-design";
const REPO = "isabellaconsorcio";

export default function GithubCommits() {
  const [commits, setCommits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchCommits() {
      setLoading(true);
      setError(null);
      try {
        const response = await base44.functions.invoke("getGithubCommits", {
          owner: OWNER,
          repo: REPO,
        });
        if (response.data.error) {
          setError(response.data.error);
        } else {
          setCommits(response.data.commits);
        }
      } catch {
        // Silently hide section on error (e.g. empty repo)
      }
      setLoading(false);
    }
    fetchCommits();
  }, []);

  if (!loading && (error || commits.length === 0)) return null;

  return (
    <section className="py-16 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-8 flex items-center gap-3"
        >
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <GitCommit className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">Últimos Commits</h2>
            <p className="text-sm text-muted-foreground">{OWNER}/{REPO}</p>
          </div>
        </motion.div>

        {loading && (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        )}

        {error && (
          <div className="flex items-center gap-3 text-destructive bg-destructive/10 rounded-xl px-4 py-3">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span className="text-sm">{error}</span>
          </div>
        )}

        {!loading && !error && (
          <div className="space-y-3">
            {commits.map((commit, i) => (
              <motion.div
                key={commit.sha}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="flex items-start gap-4 bg-muted rounded-xl px-5 py-4 hover:bg-primary/5 transition-colors"
              >
                <code className="text-xs font-mono text-primary bg-primary/10 rounded px-2 py-1 mt-0.5 shrink-0">
                  {commit.sha}
                </code>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{commit.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {commit.author} ·{" "}
                    {formatDistanceToNow(new Date(commit.date), { addSuffix: true, locale: ptBR })}
                  </p>
                </div>
                <a
                  href={commit.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="shrink-0 text-muted-foreground hover:text-primary transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}