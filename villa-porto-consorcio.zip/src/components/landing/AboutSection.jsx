import React from "react";
import { motion } from "framer-motion";
import { ShieldCheck, Award, Users } from "lucide-react";
import { Button } from "@/components/ui/button";

const ISABELLA_PHOTO = "https://media.base44.com/images/public/69bc0060bc4e860dd5230ca2/b1f1060c7_IMG_5132JPG.jpg";

export default function AboutSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Photo */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative flex justify-center"
          >
            <div className="relative">
              {/* Background decoration */}
              <div className="absolute -top-4 -left-4 w-full h-full rounded-3xl bg-primary/10" />
              <div className="relative rounded-3xl overflow-hidden shadow-2xl shadow-primary/15 max-w-sm mx-auto">
                <img
                  src={ISABELLA_PHOTO}
                  alt="Isabella Villani - Consultora de Consórcios Porto Seguro"
                  className="w-full h-auto object-cover"
                />
              </div>
              {/* Floating badge */}
              <div className="absolute -bottom-5 -right-2 sm:right-4 bg-primary rounded-2xl px-5 py-4 shadow-xl text-white text-center">
                <div className="text-2xl font-extrabold">+500</div>
                <div className="text-xs text-white/80 mt-0.5">clientes atendidos</div>
              </div>
            </div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-primary font-semibold text-sm tracking-wider uppercase">
              Quem sou eu
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3 mb-6">
              Isabella Villani
              <span className="block text-lg text-primary font-semibold mt-1">
                Consultora Autorizada Porto Seguro
              </span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              Sou especialista em consórcios e investimentos pela Porto Seguro, com anos de experiência ajudando pessoas a realizarem seus sonhos de forma inteligente, planejada e sem juros.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Acredito que cada cliente merece um atendimento personalizado. Por isso, analiso o seu momento de vida e te apresento o plano ideal para conquistar seu objetivo com parcelas que cabem no seu bolso.
            </p>

            <div className="grid sm:grid-cols-3 gap-4 mb-8">
              {[
                { icon: ShieldCheck, label: "Consultora autorizada Porto Seguro" },
                { icon: Award, label: "Especialista em consórcios e investimentos" },
                { icon: Users, label: "Atendimento 100% personalizado" },
              ].map((item) => (
                <div
                  key={item.label}
                  className="flex flex-col items-center text-center gap-2 bg-muted rounded-xl p-4"
                >
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-xs text-muted-foreground leading-tight">{item.label}</span>
                </div>
              ))}
            </div>

            <a href="#contato">
              <Button className="bg-primary hover:bg-primary/90 rounded-full px-8 text-base font-semibold">
                Fale com a Isabella
              </Button>
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}