import React from "react";
import { Button } from "@/components/ui/button";
import { Check, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const plans = [
  { months: 50, highlight: false },
  { months: 72, highlight: false },
  { months: 80, highlight: true },
  { months: 90, highlight: false },
];

export default function PlansSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-primary font-semibold text-sm tracking-wider uppercase">
            Nossos Planos
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3">
            Escolha o plano ideal para você
          </h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Taxa de administração a partir de 0,17% ao mês. Parcelas reduzidas em até 45% até a contemplação.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.months}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`rounded-2xl p-6 border-2 transition-all duration-300 hover:shadow-xl ${
                plan.highlight
                  ? "border-primary bg-primary/5 shadow-lg shadow-primary/10"
                  : "border-border/40 bg-white hover:border-primary/30"
              }`}
            >
              {plan.highlight && (
                <div className="inline-block bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full mb-4">
                  Mais Popular
                </div>
              )}
              <div className="text-center mb-6">
                <span className="text-5xl font-extrabold text-foreground">{plan.months}</span>
                <span className="text-muted-foreground text-lg ml-1">meses</span>
              </div>
              <div className="space-y-3 mb-6">
                {[
                  "Sem juros",
                  "Sem entrada",
                  "Parcelas reduzidas",
                  "Contemplação mensal",
                ].map((feature) => (
                  <div key={feature} className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-primary shrink-0" />
                    <span className="text-sm text-foreground/80">{feature}</span>
                  </div>
                ))}
              </div>
              <a href="#contato">
                <Button
                  className={`w-full rounded-xl ${
                    plan.highlight
                      ? "bg-primary hover:bg-primary/90"
                      : "bg-foreground/5 text-foreground hover:bg-foreground/10"
                  }`}
                >
                  Simular
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}