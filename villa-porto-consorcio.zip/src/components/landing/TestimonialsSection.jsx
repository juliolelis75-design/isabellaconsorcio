import React from "react";
import { Star, Quote } from "lucide-react";
import { motion } from "framer-motion";

const testimonials = [
  {
    name: "Carlos",
    city: "São Paulo",
    text: "Sou cliente do consórcio da Porto há 10 anos e sempre tive um atendimento respeitoso. A Isabella me ajudou a encontrar o plano perfeito!",
    initials: "C",
  },
  {
    name: "Aline",
    city: "São Paulo",
    text: "Graças à Porto, conquistei meu carro dos sonhos! Já faz 1 ano da minha conquista. Recomendo demais o atendimento da Isabella.",
    initials: "A",
  },
  {
    name: "Gabriel",
    city: "São Paulo",
    text: "Com o sonho do carro próprio, comprei uma cota de consórcio. O processo foi simples e transparente do início ao fim.",
    initials: "G",
  },
  {
    name: "Ana Paula",
    city: "Rio de Janeiro",
    text: "Eu comprei a cota de consórcio pois sou do tipo que só guarda dinheiro se tem um boleto para pagar. Melhor decisão que tomei!",
    initials: "AP",
  },
];

export default function TestimonialsSection() {
  return (
    <section id="depoimentos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-primary font-semibold text-sm tracking-wider uppercase">
            Depoimentos
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mt-3">
            Que tal se inspirar com histórias reais?
          </h2>
          <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
            Em breve, pode ser a sua conquista
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((t, index) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-muted rounded-2xl p-6 relative group hover:shadow-lg transition-all duration-300"
            >
              <Quote className="w-8 h-8 text-primary/15 absolute top-4 right-4" />

              {/* Stars */}
              <div className="flex gap-0.5 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>

              <p className="text-sm text-foreground/80 leading-relaxed mb-6 min-h-[100px]">
                "{t.text}"
              </p>

              <div className="flex items-center gap-3 pt-4 border-t border-border/40">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-primary font-semibold text-sm">
                    {t.initials}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.city}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}