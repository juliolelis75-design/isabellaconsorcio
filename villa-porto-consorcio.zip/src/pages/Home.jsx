import React from "react";
import Navbar from "@/components/landing/Navbar";
import HeroSection from "@/components/landing/HeroSection";
import ConsorcioTypesSection from "@/components/landing/ConsorcioTypesSection";
import StepsSection from "@/components/landing/StepsSection";
import BenefitsSection from "@/components/landing/BenefitsSection";
import AboutSection from "@/components/landing/AboutSection";
import ContactForm from "@/components/landing/ContactForm";
import PlansSection from "@/components/landing/PlansSection";
import TestimonialsSection from "@/components/landing/TestimonialsSection";
import FAQSection from "@/components/landing/FAQSection";
import Footer from "@/components/landing/Footer";
import WhatsAppButton from "@/components/landing/WhatsAppButton";
import GithubCommits from "@/components/landing/GithubCommits";

const HERO_IMAGE = "https://media.base44.com/images/public/69bc0060bc4e860dd5230ca2/3881ef48f_generated_image.png";
const COUPLE_IMAGE = "https://media.base44.com/images/public/69bc0060bc4e860dd5230ca2/96cae0bd5_generated_0bec0b76.png";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection heroImage={HERO_IMAGE} />
      <ConsorcioTypesSection />
      <ContactForm />
      <AboutSection />
      <StepsSection />
      <BenefitsSection coupleImage={COUPLE_IMAGE} />
      <PlansSection />
      <TestimonialsSection />
      <FAQSection />
      <GithubCommits />
      <Footer />
      <WhatsAppButton />
    </div>
  );
}